import itertools
import torch
import math
from src.agents.random_agent import RandomAgent
from src.agents.dueling_dqn import DuelingDQN
from src.agents.ddqn import DDQN
from src.agents.dqn import DQN

from src.estimators import NNEstimator, DuelingNNEstimator
from src.replay_buffer import ReplayBuffer

from typing import Optional, Callable

def get_agent(
    env,
    opt,
    agent: str = 'dqn',
    replay_buffer_size: int = 100_000,
    batch_size: int = 32,
    lr: float = 6.25e-4,
    eps: float = 1e-5,
    warmup_steps_percent: float = 0.1,
    update_steps: int = 1,
    update_target_steps: int = 10,
    estimator: Optional[Callable] = None,
    optimizer: Optional[Callable] = None,
    epsilon_schedule: Optional[Callable] = None
):

    device = opt.device
    action_num = env.action_space.n
    warmup_steps = opt.steps * warmup_steps_percent

    if estimator is None:
        if agent != 'dueling':
            estimator = NNEstimator(action_num).to(device)
        else:
            estimator = DuelingNNEstimator(action_num).to(device)


    if optimizer is None:
        optimizer = torch.optim.Adam(estimator.parameters(), lr=lr, eps=eps)

    if epsilon_schedule is None:
         epsilon_schedule = get_epsilon_schedule_cosine(total_steps=opt.steps, warmup_steps=warmup_steps, num_cycles=2)
        #  epsilon_schedule = get_epsilon_schedule(total_steps=opt.steps, warmup_steps=warmup_steps)

    buffer = ReplayBuffer(device, size=replay_buffer_size, batch_size=batch_size)


    if agent == 'dqn':
        agent = DQN(estimator, buffer, optimizer, epsilon_schedule, action_num,
                    warmup_steps=warmup_steps, update_steps=update_steps)

    elif agent == 'ddqn':
        agent =  DDQN(estimator, buffer, optimizer, epsilon_schedule, action_num,
                      warmup_steps=warmup_steps, update_steps=update_steps, update_target_steps=update_target_steps)


    elif agent == 'dueling':
        agent = DuelingDQN(estimator, buffer, optimizer, epsilon_schedule, action_num,
                          warmup_steps=warmup_steps, update_steps=update_steps,
                          update_target_steps=update_target_steps)

    elif agent == 'random':
        agent = RandomAgent(action_num)

    else:
        # if no valid agent type was chosen then return random agent
        agent = RandomAgent(action_num)

    print(f"Agent: {agent}")

    return agent

def get_epsilon_schedule_cosine(total_steps, warmup_steps, num_cycles):
    cycle = -1
    warmup_done = False
    def to_return():
        for current_step in range(total_steps):
            yield(epsilon_decay(current_step, total_steps, warmup_steps, num_cycles))
    
    def epsilon_decay(current_step, total_steps, warmup_steps, num_cycles):
        nonlocal cycle, warmup_done
        def map_interval(a,b,c,d,t):
            return c + (d - c)/(b - a) * (t - a)
    
        if warmup_done == False:
            if current_step == warmup_steps:
                warmup_done = True
                cycle += 1
            return 1
        else:   
            current_step -= warmup_steps
            total_steps -= warmup_steps

        progress = float(current_step) / float(total_steps)
        if progress >= 1.0:
            return 0.0
        procent = (float(num_cycles) * progress)
        if procent % 1.0 == 0.0:
            cycle += 1

        cos_value = 0.5 * (1.0 + math.cos(math.pi * (procent % 1.0)))
        a, b = 0.0, 1.0
        c, d = 0.0, 1.0 - (cycle / float(num_cycles))
        return max(0.05, map_interval(a,b,c,d,cos_value))
    
    return itertools.chain(to_return(), itertools.repeat(0.05))

def get_epsilon_schedule(total_steps=100000, warmup_steps=10000):
    start = 1.0
    end = 0.05
    total_steps = total_steps - warmup_steps
    eps_step = (start - end) / total_steps
    def frange(start, end, step):
        x = start
        while x > end:
            yield x
            x -= step
    return itertools.chain(frange(start, end, eps_step), itertools.repeat(end))
